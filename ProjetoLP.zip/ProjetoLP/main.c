#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LLholder.h"


#define MAX_WORD_LENGTH 50

ConjuntosPalavras* criarConjuntosPalavras(int capacidade) {
    ConjuntosPalavras* conjuntos = (ConjuntosPalavras*)malloc(sizeof(ConjuntosPalavras));
    conjuntos->capacidade = capacidade;

    for (int i = 0; i < 2; i++) {
        conjuntos->palavras[i] = (char**)malloc(capacidade * sizeof(char*));
        conjuntos->codigos_UFP6[i] = (char**)malloc(capacidade * sizeof(char*));
        conjuntos->tamanho[i] = 0;
    }

    return conjuntos;
}

void freeConjuntosPalavras(ConjuntosPalavras* conjuntos) {
    // free memória alocada para cada conjunto de strings
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < conjuntos->tamanho[i]; j++) {
            free(conjuntos->palavras[i][j]);
            free(conjuntos->codigos_UFP6[i][j]);
        }
        free(conjuntos->palavras[i]);
        free(conjuntos->codigos_UFP6[i]);
    }

    // Liberar a estrutura ConjuntosPalavras
    free(conjuntos);
}


char* palavraParaUFP6(char* palavra) {
    int tamanho = strlen(palavra);
    char* resultado = (char*)malloc((6 * tamanho + 1) * sizeof(char)); // Tamanho máximo para cada caractere UFP6

    resultado[0] = '\0';
    for (int i = 0; i < tamanho; i++) {
        char caractere = palavra[i];
        char* codigo_UFP6 = dicionario_UFP6[(int)caractere];

        strcat(resultado, codigo_UFP6);
    }

    return resultado;
}

void adicionarPalavra(ConjuntosPalavras* conjuntos, int conjunto_num, char* palavra) {
    if (conjunto_num < 1 || conjunto_num > 2) {
        printf("Número de conjunto inválido.\n");
        return;
    }

    int indice_conjunto = conjunto_num - 1; // Ajusta para índice (0 ou 1)
    int tamanho_atual = conjuntos->tamanho[indice_conjunto];

    if (tamanho_atual >= conjuntos->capacidade) {
        printf("Capacidade máxima atingida no conjunto %d. Não é possível adicionar mais palavras.\n", conjunto_num);
        return;
    }

    conjuntos->palavras[indice_conjunto][tamanho_atual] = strdup(palavra);
    conjuntos->codigos_UFP6[indice_conjunto][tamanho_atual] = palavraParaUFP6(palavra);

    conjuntos->tamanho[indice_conjunto]++;
}

void apagarPalavra(ConjuntosPalavras* conjuntos, int conjunto_num, char* palavra) {
    if (conjunto_num < 1 || conjunto_num > 2) {
        printf("Número de conjunto inválido.\n");
        return;
    }

    int indice_conjunto = conjunto_num - 1; // Ajusta para índice (0 ou 1)
    int tamanho_atual = conjuntos->tamanho[indice_conjunto];

    // Search for the word in the array
    int index_to_delete = -1;
    for (int i = 0; i < tamanho_atual; i++) {
        if (strcmp(conjuntos->palavras[indice_conjunto][i], palavra) == 0) {
            index_to_delete = i;
            break;
        }
    }

    if (index_to_delete != -1) {
        // Free memory for the word and its UFP6 code
        free(conjuntos->palavras[indice_conjunto][index_to_delete]);
        free(conjuntos->codigos_UFP6[indice_conjunto][index_to_delete]);

        // Move remaining elements to fill the gap
        for (int i = index_to_delete; i < tamanho_atual - 1; i++) {
            conjuntos->palavras[indice_conjunto][i] = conjuntos->palavras[indice_conjunto][i + 1];
            conjuntos->codigos_UFP6[indice_conjunto][i] = conjuntos->codigos_UFP6[indice_conjunto][i + 1];
        }

        conjuntos->tamanho[indice_conjunto]--;

        // Reallocate memory to shrink the arrays
        conjuntos->palavras[indice_conjunto] = realloc(conjuntos->palavras[indice_conjunto], conjuntos->tamanho[indice_conjunto] * sizeof(char*));
        conjuntos->codigos_UFP6[indice_conjunto] = realloc(conjuntos->codigos_UFP6[indice_conjunto], conjuntos->tamanho[indice_conjunto] * sizeof(char*));
    }
}

void listarPalavrasUFP6(ConjuntosPalavras* conjuntos) {
    for (int j = 0; j < 2; j++) {
        printf("Conjunto %d:\n", j + 1);
        for (int i = 0; i < conjuntos->tamanho[j]; i++) {
            printf("Palavra: %s\tCodigo UFP6: %s\n", conjuntos->palavras[j][i], conjuntos->codigos_UFP6[j][i]);
        }
    }
}


void inicializarDicionario() {
    // Inicialização para dígitos (ASCII 48 a 57)
    for (int i = 48; i <= 57; i++) {
        int valor = i - 48; // Valor do dígito
        char* binarios[10] = { "0", "1", "10", "11", "100", "101", "110", "111", "1000", "1001" };

        dicionario_UFP6[i] = strdup(binarios[valor]); // Armazenar a representação UFP6 no dicionário
    }

    // Inicialização para letras minúsculas (ASCII 97 a 122)
    for (int i = 97; i <= 122; i++) {
        int indice = i - 97; // Índice para mapear a letra para o dicionário
        char* binarios[26] = {
                "1010", "1011", "1100", "1101", "1110", "1111", "10000", "10001", "10010", "10011",
                "10100", "10101", "10110", "10111", "11000", "11001", "11010", "11011", "11100", "11101",
                "11110", "11111", "100000", "100001", "100010", "100011"
        };

        dicionario_UFP6[i] = strdup(binarios[indice]); // Armazenar a representação UFP6 no dicionário
    }

    for (int i = 65; i <= 90; i++) {
        int indice = i - 65; // Índice para mapear a letra maiúscula para o dicionário
        char* binarios[26] = {
                "100100", "100101", "100110", "100111", "101000", "101001", "101010", "101011", "101100",
                "101101", "101110", "101111", "110000", "110001", "110010", "110011", "110100",
                "110101", "110110", "110111", "111000", "111101", "111010", "111011", "111100",
                "111101"
        };

        dicionario_UFP6[i] = strdup(binarios[indice]); // Armazenar a representação UFP6 no dicionário
    }
}

void pesquisarPalavra(ConjuntosPalavras* conjuntos, char* palavra) {
    if (conjuntos == NULL || palavra == NULL || palavra[0] == '\0') {
        printf("Entrada inválida.\n");
        return;
    }

    int found = 0;
    for (int conjunto_num = 1; conjunto_num <= 2; conjunto_num++) {
        int indice_conjunto = conjunto_num - 1; // Convert to array index

        for (int i = 0; i < conjuntos->tamanho[indice_conjunto]; i++) {
            if (strcmp(conjuntos->palavras[indice_conjunto][i], palavra) == 0) {
                found = 1;
                printf("Palavra encontrada no conjunto %d, indice %d, codigo binario: %s.\n", conjunto_num, i, conjuntos->codigos_UFP6[indice_conjunto][i]);
                // If you want to stop after finding the word once, uncomment the return statement below
                // return;
                // Otherwise, it continues searching for all occurrences of the exact word.
            }
        }
    }

    if (!found) {
        printf("A palavra nao foi encontrada nos conjuntos.\n");
    }
}

int compararConjuntosUFP6(ConjuntosPalavras* conjuntos, int conjunto1, int conjunto2) {
    if (conjuntos == NULL || conjunto1 < 1 || conjunto1 > 2 || conjunto2 < 1 || conjunto2 > 2) {
        printf("Entrada inválida.\n");
        return 0; // Indica falha
    }

    int indice_conjunto1 = conjunto1 - 1;
    int indice_conjunto2 = conjunto2 - 1;
    int flag = 0;

    for (int i = 0; i < conjuntos->tamanho[indice_conjunto1]; i++) {
        for (int j = 0; j < conjuntos->tamanho[indice_conjunto2]; j++) {
            if (strcmp(conjuntos->codigos_UFP6[indice_conjunto1][i], conjuntos->codigos_UFP6[indice_conjunto2][j]) == 0) {
                printf("Combinacao encontrada:\n");
                printf("Conjunto %d, Palavra %d: %s\tCodigo UFP6: %s\n", conjunto1, i + 1, conjuntos->palavras[indice_conjunto1][i], conjuntos->codigos_UFP6[indice_conjunto1][i]);
                printf("Conjunto %d, Palavra %d: %s\tCodigo UFP6: %s\n", conjunto2, j + 1, conjuntos->palavras[indice_conjunto2][j], conjuntos->codigos_UFP6[indice_conjunto2][j]);
                flag = 1;
            }
        }
    }
    if (flag == 1) {
        printf("Sem mais combinacoes\n");
    } else {
        printf("Nenhuma combinacao encontrada.\n");
    }
    return 0; // Indica que nenhuma combinação foi encontrada
}

void ordenarAlfabeticamente(ConjuntosPalavras* conjuntos) { //palavras com Maiusculas ficam primeiro
    if (conjuntos == NULL) {
        printf("Estrutura inválida.\n");
        return;
    }

    for (int conjunto_num = 1; conjunto_num <= 2; conjunto_num++) {
        int indice_conjunto = conjunto_num - 1; // Convert to array index

        // Bubble sort to sort the words alphabetically
        for (int i = 0; i < conjuntos->tamanho[indice_conjunto] - 1; i++) {
            for (int j = 0; j < conjuntos->tamanho[indice_conjunto] - i - 1; j++) {
                // Compare adjacent strings and swap if necessary
                if (strcmp(conjuntos->palavras[indice_conjunto][j], conjuntos->palavras[indice_conjunto][j + 1]) > 0) {
                    // Swap words
                    char* temp_word = conjuntos->palavras[indice_conjunto][j];
                    conjuntos->palavras[indice_conjunto][j] = conjuntos->palavras[indice_conjunto][j + 1];
                    conjuntos->palavras[indice_conjunto][j + 1] = temp_word;

                    // Swap UFP6 codes accordingly
                    char* temp_code = conjuntos->codigos_UFP6[indice_conjunto][j];
                    conjuntos->codigos_UFP6[indice_conjunto][j] = conjuntos->codigos_UFP6[indice_conjunto][j + 1];
                    conjuntos->codigos_UFP6[indice_conjunto][j + 1] = temp_code;
                }
            }
        }
    }
}

//SEGUNDA FASE
//WORDS_HOLDER* criarWORDS_HOLDER(int capacidade) {
//    WORDS_HOLDER* holder = (WORDS_HOLDER*)malloc(sizeof(WORDS_HOLDER));
//    holder->conjuntoAlfaNumerico = criarConjuntosPalavras(capacidade);
//    holder->conjuntoUFP6 = criarConjuntosPalavras(capacidade);
//
//    return holder;
//}

AD_WORDS_HOLDER* criarOuRedimensionarArray(int novoTamanho, AD_WORDS_HOLDER* array) {
    if (array == NULL) {
        // Se o array não existir, cria um novo
        array = (AD_WORDS_HOLDER *) malloc(sizeof(AD_WORDS_HOLDER));

        if (array == NULL) {
            // Tratamento de erro na alocação de memória para a estrutura
            return NULL;
        }

        array->elementos = 0;
        array->tamanho = novoTamanho;
        array->primeiroElemento = (VAL_AD_WORDS_HOLDER *) malloc(novoTamanho * sizeof(VAL_AD_WORDS_HOLDER));

        if (array->primeiroElemento == NULL) {
            // Tratamento de erro na alocação de memória para o primeiroElemento
            free(array);
            return NULL;
        }
    } else {
        // Se o array já existir, redimensiona-o
        VAL_AD_WORDS_HOLDER *novoPrimeiroElemento = (VAL_AD_WORDS_HOLDER *) realloc(array->primeiroElemento,
                                                                                    novoTamanho *
                                                                                    sizeof(VAL_AD_WORDS_HOLDER));

        if (novoPrimeiroElemento == NULL) {
            // Tratamento de erro na realocação de memória
            return NULL;
        }

        array->primeiroElemento = novoPrimeiroElemento;
        array->tamanho = novoTamanho;
    }

    return array;
}
void imprimirArray(AD_WORDS_HOLDER* array) {
    if (array == NULL) {
        printf("Array nao inicializado.\n");
        return;
    }

    printf("Elementos no array: %d\n", array->elementos);
    printf("Tamanho do array: %d\n", array->tamanho);
}

void testarCriarOuRedimensionarArray() {
    AD_WORDS_HOLDER* meuArray = NULL;

    // Criar um array com tamanho inicial de 10
    printf("Criando array...\n");
    meuArray = criarOuRedimensionarArray(10, meuArray);
    imprimirArray(meuArray);

    // Redimensionar o array para tamanho 5
    printf("\nRedimensionando array para tamanho 5...\n");
    meuArray = criarOuRedimensionarArray(5, meuArray);
    imprimirArray(meuArray);

    // Redimensionar o array para tamanho 15
    printf("\nRedimensionando array para tamanho 15...\n");
    meuArray = criarOuRedimensionarArray(15, meuArray);
    imprimirArray(meuArray);

    // Liberar memória do array
    if (meuArray != NULL) {
        free(meuArray->primeiroElemento);
        free(meuArray);
    }
}

void inserirElementoOrdenado(AD_WORDS_HOLDER* array, VAL_AD_WORDS_HOLDER novoElemento) {
    // Verifica se o array ou o novo elemento são nulos
    if (array == NULL || novoElemento.dataUltimaModificacao[0] == '\0') {
        // Tratamento de erro
        return;
    }

    // Se o array estiver vazio ou o novo elemento tiver uma data mais recente que o primeiro elemento
    if (array->elementos == 0 || strcmp(novoElemento.dataUltimaModificacao, array->primeiroElemento[0].dataUltimaModificacao) < 0) {
        // Insere o novo elemento no início do array
        for (int i = array->elementos; i > 0; i--) {
            array->primeiroElemento[i] = array->primeiroElemento[i - 1];
        }
        array->primeiroElemento[0] = novoElemento;
        array->elementos++;
        return;
    }

    // Procura a posição correta para inserir o novo elemento
    int i = array->elementos - 1;
    while (i >= 0 && strcmp(novoElemento.dataUltimaModificacao, array->primeiroElemento[i].dataUltimaModificacao) < 0) {
        array->primeiroElemento[i + 1] = array->primeiroElemento[i];
        i--;
    }

    // Insere o novo elemento na posição correta
    array->primeiroElemento[i + 1] = novoElemento;
    array->elementos++;
}
void imprimirArray2(AD_WORDS_HOLDER* array) {
    printf("Elementos no array: %d\n", array->elementos);
    for (int i = 0; i < array->elementos; i++) {
        printf("Elemento %d - Data de Modificacao: %s\n", i + 1, array->primeiroElemento[i].dataUltimaModificacao);
    }
}

void testarInserirElementoOrdenado() {
    // Criação do array
    AD_WORDS_HOLDER* meuArray = (AD_WORDS_HOLDER*)malloc(sizeof(AD_WORDS_HOLDER));
    meuArray->tamanho = 10;
    meuArray->elementos = 0;
    meuArray->primeiroElemento = (VAL_AD_WORDS_HOLDER*)malloc(meuArray->tamanho * sizeof(VAL_AD_WORDS_HOLDER));

    // Criação de novos elementos para inserir
    VAL_AD_WORDS_HOLDER novoElemento1, novoElemento2, novoElemento3;
    strcpy(novoElemento1.dataUltimaModificacao, "2022-01-01");
    strcpy(novoElemento2.dataUltimaModificacao, "2022-01-03");
    strcpy(novoElemento3.dataUltimaModificacao, "2022-01-02");

    // Inserção dos elementos no array
    inserirElementoOrdenado(meuArray, novoElemento1);
    inserirElementoOrdenado(meuArray, novoElemento2);
    inserirElementoOrdenado(meuArray, novoElemento3);

    // Exibe o array para verificar se os elementos foram inseridos corretamente
    imprimirArray2(meuArray);

    // Libera a memória alocada
    free(meuArray->primeiroElemento);
    free(meuArray);
}

void inserirElementoPosicao(AD_WORDS_HOLDER* array, VAL_AD_WORDS_HOLDER novoElemento, int posicao) {
    // Verifica se o array é nulo ou se a posição está fora dos limites do array
    if (array == NULL || posicao < 0 || posicao > array->elementos) {
        printf("Erro: Posição inválida ou array nulo.\n");
        return;
    }

    // Se a posição for igual ao número de elementos, insere no final do array
    if (posicao == array->elementos) {
        array->primeiroElemento[array->elementos] = novoElemento;
        array->elementos++;
        printf("Elemento inserido no final do array.\n");
        return;
    }

    // Desloca os elementos para abrir espaço para o novo elemento
    for (int i = array->elementos; i > posicao; i--) {
        array->primeiroElemento[i] = array->primeiroElemento[i - 1];
    }

    // Insere o novo elemento na posição desejada
    array->primeiroElemento[posicao] = novoElemento;
    array->elementos++;
    printf("Elemento inserido na posição %d.\n", posicao);
}
void testarInserirElementoPosicao() {
    AD_WORDS_HOLDER* meuArray = (AD_WORDS_HOLDER*)malloc(sizeof(AD_WORDS_HOLDER));
    if (meuArray == NULL) {
        printf("Erro: Falha na alocação de meuArray.\n");
        return;
    }

    meuArray->tamanho = 10;
    meuArray->elementos = 0;
    meuArray->primeiroElemento = (VAL_AD_WORDS_HOLDER*)malloc(meuArray->tamanho * sizeof(VAL_AD_WORDS_HOLDER));
    if (meuArray->primeiroElemento == NULL) {
        printf("Erro: Falha na alocação de primeiroElemento.\n");
        free(meuArray);
        return;
    }

    VAL_AD_WORDS_HOLDER novoElemento;
    strcpy(novoElemento.dataUltimaModificacao, "2022-01-02");

    printf("Antes de inserirElementoPosicao: Elementos no array: %d\n", meuArray->elementos);

    int posicao = 1; // Posição para teste
    if (posicao < 0 || posicao > meuArray->elementos) {
        printf("Erro: Posicao inválida para inserção.\n");
        free(meuArray->primeiroElemento);
        free(meuArray);
        return;
    }

    printf("Chamando inserirElementoPosicao(meuArray, novoElemento, %d)...\n", posicao);
    inserirElementoPosicao(meuArray, novoElemento, posicao);

    printf("Depois de inserirElementoPosicao: Elementos no array: %d\n", meuArray->elementos);
    imprimirArray(meuArray);

    free(meuArray->primeiroElemento);
    free(meuArray);
}

void removerElementoPosicao(AD_WORDS_HOLDER* array, int posicao) {
    // Verifica se o array é nulo ou se a posição está fora dos limites do array
    if (array == NULL || posicao < 0 || posicao >= array->elementos) {
        // Tratamento de erro
        return;
    }

    // Desloca os elementos após a posição removida para ocupar o espaço
    for (int i = posicao; i < array->elementos - 1; i++) {
        array->primeiroElemento[i] = array->primeiroElemento[i + 1];
    }

    // Diminui a contagem de elementos após a remoção
    array->elementos--;
}

void pesquisarEmElementos(AD_WORDS_HOLDER* array, int inicio, int fim, char* palavra) {
    // Verifica se o array é nulo ou se as posições estão fora dos limites do array
    if (array == NULL || inicio < 0 || fim >= array->elementos || inicio > fim) {
        // Tratamento de erro ou condições inválidas
        return;
    }

    for (int i = inicio; i <= fim; i++) {
        // Realiza a pesquisa da palavra no elemento do array
        // Aqui você pode acessar array->primeiroElemento[i] para pesquisar na estrutura VAL_AD_WORDS_HOLDER
        // Se encontrar a palavra, pode exibir os detalhes ou realizar outras operações desejadas
        // Exemplo de pesquisa simplificada para a palavra:
        if (strcmp(array->primeiroElemento[i].dados.conjuntoAlfaNumerico->palavras[0][0], palavra) == 0) {
            printf("Palavra encontrada no elemento %d.\n", i);
            // Você pode adicionar outras ações aqui, como imprimir os códigos UFP6 ou outras manipulações
        }
    }
}

//terceira parte

void inserirOrdenado(LL_WORDS_HOLDER* lista, NODE_LL_WORDS_HOLDER* novoNo, char* dataModificacao) {
    if (lista == NULL || novoNo == NULL) {
        // Tratamento de erro se a lista ou o novo nó forem inválidos
        return;
    }

    NODE_LL_WORDS_HOLDER* atual = lista->primeiroNo;
    NODE_LL_WORDS_HOLDER* anterior = NULL;

    // Procura a posição correta para inserir o novo nó ordenadamente pela data de modificação
    while (atual != NULL && strcmp(dataModificacao, atual->dataUltimaModificacao) > 0) {
        anterior = atual;
        atual = atual->proximo;
    }

    // Insere o novo nó na posição encontrada
    if (anterior == NULL) {
        // Se for o primeiro nó da lista
        novoNo->proximo = lista->primeiroNo;
        novoNo->anterior = NULL;
        if (lista->primeiroNo != NULL) {
            lista->primeiroNo->anterior = novoNo;
        }
        lista->primeiroNo = novoNo;
    } else {
        novoNo->proximo = anterior->proximo;
        novoNo->anterior = anterior;
        anterior->proximo = novoNo;
        if (atual != NULL) {
            atual->anterior = novoNo;
        }
    }

    lista->numeroNos++;
}

void inserirNaPosicao(LL_WORDS_HOLDER* lista, NODE_LL_WORDS_HOLDER* novoNo, int posicao) {
    if (lista == NULL || novoNo == NULL || posicao < 0) {
        // Tratamento de erro para parâmetros inválidos
        return;
    }

    NODE_LL_WORDS_HOLDER* atual = lista->primeiroNo;
    NODE_LL_WORDS_HOLDER* anterior = NULL;
    int contador = 0;

    // Move para a posição desejada na lista
    while (atual != NULL && contador < posicao) {
        anterior = atual;
        atual = atual->proximo;
        contador++;
    }

    // Verifica se a posição desejada foi alcançada
    if (contador == posicao) {
        // Insere o novo nó na posição encontrada
        if (anterior == NULL) {
            // Inserir no início da lista
            novoNo->proximo = lista->primeiroNo;
            novoNo->anterior = NULL;
            if (lista->primeiroNo != NULL) {
                lista->primeiroNo->anterior = novoNo;
            }
            lista->primeiroNo = novoNo;
        } else {
            novoNo->proximo = anterior->proximo;
            novoNo->anterior = anterior;
            anterior->proximo = novoNo;
            if (atual != NULL) {
                atual->anterior = novoNo;
            }
        }

        lista->numeroNos++;
    } else {
        // A posição não foi encontrada na lista
        printf("Posição inválida.\n");
    }
}

void removerDaPosicao(LL_WORDS_HOLDER* lista, int posicao) {
    if (lista == NULL || posicao < 0) {
        // Tratamento de erro para parâmetros inválidos
        return;
    }

    NODE_LL_WORDS_HOLDER* atual = lista->primeiroNo;
    NODE_LL_WORDS_HOLDER* anterior = NULL;
    int contador = 0;

    // Move para a posição desejada na lista
    while (atual != NULL && contador < posicao) {
        anterior = atual;
        atual = atual->proximo;
        contador++;
    }

    // Verifica se a posição desejada foi alcançada
    if (contador == posicao && atual != NULL) {
        // Remove o nó na posição encontrada
        if (anterior == NULL) {
            // Remoção no início da lista
            lista->primeiroNo = atual->proximo;
            if (atual->proximo != NULL) {
                atual->proximo->anterior = NULL;
            }
        } else {
            anterior->proximo = atual->proximo;
            if (atual->proximo != NULL) {
                atual->proximo->anterior = anterior;
            }
        }

        free(atual); // Libera memória do nó removido
        lista->numeroNos--;
    } else {
        // A posição não foi encontrada na lista ou a lista está vazia
        printf("Posição inválida.\n");
    }
}

void pesquisarEmNos(LL_WORDS_HOLDER* lista, int inicio, int fim, char* palavra) {
    if (lista == NULL || inicio < 0 || fim >= lista->numeroNos || inicio > fim) {
        // Tratamento de erro para parâmetros inválidos
        return;
    }

    NODE_LL_WORDS_HOLDER* atual = lista->primeiroNo;
    int contador = 0;

    // Move para o nó inicial
    while (contador < inicio && atual != NULL) {
        atual = atual->proximo;
        contador++;
    }

    // Itera entre os nós desejados para realizar a pesquisa
    while (contador <= fim && atual != NULL) {
        // Realiza a pesquisa da palavra no nó atual
        // Aqui você pode acessar as estruturas WORDS_HOLDER no nó atual
        // para pesquisar palavras e códigos UFP6
        // Exemplo de pesquisa simplificada para a palavra:
        if (strcmp(atual->dados.conjuntoAlfaNumerico->palavras[0][0], palavra) == 0) {
            printf("Palavra encontrada no nó %d.\n", contador);
            // Realize operações necessárias quando a palavra é encontrada
        }

        atual = atual->proximo;
        contador++;
    }
}

// Função para escrever dados em um arquivo
void escreverEmArquivo(char* nomeArquivo, ConjuntosPalavras* conjuntos) {
    FILE* arquivo = fopen(nomeArquivo, "w"); // Abre o arquivo para escrita

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para escrita.\n");
        return;
    }

    // Escreve os conjuntos de palavras e códigos UFP6 no arquivo
    for (int j = 0; j < 2; j++) {
        fprintf(arquivo, "Conjunto %d:\n", j + 1);
        for (int i = 0; i < conjuntos->tamanho[j]; i++) {
            fprintf(arquivo, "Palavra: %s\tCodigo UFP6: %s\n", conjuntos->palavras[j][i], conjuntos->codigos_UFP6[j][i]);
        }
    }
    printf("Ecrito com sucesso!");
    fclose(arquivo); // Fecha o arquivo após a escrita
}

// Função para ler dados de um arquivo
void lerDeArquivo(char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "r"); // Abre o arquivo para leitura

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para leitura.\n");
        return;
    }

    char linha[100]; // Variável para armazenar cada linha lida do arquivo

    // Lê e exibe o conteúdo do arquivo linha por linha
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        printf("%s", linha); // Exibe a linha lida
    }
    printf("Lido com sucesso!");

    fclose(arquivo); // Fecha o arquivo após a leitura
}

void escreverEmArquivoBinario(char* nomeArquivo, ConjuntosPalavras* conjuntos) {
    FILE* arquivo = fopen(nomeArquivo, "wb"); // Abre o arquivo para escrita binária

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para escrita binária.\n");
        return;
    }

    // Escreve os conjuntos de palavras e códigos UFP6 no arquivo binário
    fwrite(conjuntos, sizeof(ConjuntosPalavras), 1, arquivo);

    printf("Ecrito no arquivo binario com sucesso!");
    fclose(arquivo); // Fecha o arquivo após a escrita
}

void lerDeArquivoBinario(char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "rb"); // Abre o arquivo para leitura binária

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo binário.\n");
        return;
    }

    ConjuntosPalavras conjuntos;

    // Lê os conjuntos de palavras e códigos UFP6 do arquivo binário
    fread(&conjuntos, sizeof(ConjuntosPalavras), 1, arquivo);

    printf("Lido do arquivo binario com sucesso!");

    fclose(arquivo); // Fecha o arquivo após a leitura
}



int main() {

    inicializarDicionario(); // Inicializa o dicionário

    int capacidade = 100; // Capacidade desejada para cada conjunto
    ConjuntosPalavras* conjuntos = criarConjuntosPalavras(capacidade);

    adicionarPalavra(conjuntos, 1,"adc");
    adicionarPalavra(conjuntos, 1,"abc");
    adicionarPalavra(conjuntos,1,"123");
    adicionarPalavra(conjuntos,1,"abcd");
    adicionarPalavra(conjuntos,1,"abcde");
    adicionarPalavra(conjuntos,1,"Abcdd");
    adicionarPalavra(conjuntos,1,"aBcdd");
    adicionarPalavra(conjuntos,2,"aTa");
    adicionarPalavra(conjuntos, 2, "123");
    adicionarPalavra(conjuntos,2, "abcd");

    //listarPalavrasUFP6(conjuntos);

    apagarPalavra(conjuntos, 1, "adc");

    //listarPalavrasUFP6(conjuntos);

    //pesquisarPalavra(conjuntos, "aaa");

    ordenarAlfabeticamente(conjuntos);

    listarPalavrasUFP6(conjuntos);

    //compararConjuntosUFP6(conjuntos, 1, 2);

    //testarCriarOuRedimensionarArray();

    testarInserirElementoOrdenado();
    //testarInserirElementoPosicao();

    char nome[]={"teste1.txt"};
    escreverEmArquivo(nome, conjuntos);
    lerDeArquivo(nome);

    char nome2[]={"teste2.txt"};
    escreverEmArquivoBinario(nome2, conjuntos);
    lerDeArquivoBinario(nome2);

    freeConjuntosPalavras(conjuntos);


    return 0;
}

