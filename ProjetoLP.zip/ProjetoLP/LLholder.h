//
// Created by Frederico on 21/12/2023.
//

#ifndef PROJETOLP_LLHOLDER_H
#define PROJETOLP_LLHOLDER_H

char* dicionario_UFP6[128]; // Array para armazenar o dicionário

typedef struct {
    char **palavras[2]; // Matriz dinâmica para armazenar as palavras dos dois conjuntos
    char **codigos_UFP6[2]; // Matriz dinâmica para armazenar os códigos UFP6 dos dois conjuntos
    int tamanho[2]; // Número atual de palavras armazenadas em cada conjunto
    int capacidade; // Capacidade máxima de cada conjunto
} ConjuntosPalavras;

typedef struct {
    ConjuntosPalavras* conjuntoAlfaNumerico;
    ConjuntosPalavras* conjuntoUFP6;
} WORDS_HOLDER;

typedef struct {
    WORDS_HOLDER dados;
    char dataUltimaModificacao[20]; // Por exemplo, uma string para armazenar a data
} VAL_AD_WORDS_HOLDER;

typedef struct {
    int tamanho;
    int elementos;
    VAL_AD_WORDS_HOLDER* primeiroElemento;
} AD_WORDS_HOLDER;

typedef struct node_ll_words_holder {
    WORDS_HOLDER dados;
    char dataUltimaModificacao[20]; // Exemplo de armazenamento da data
    struct node_ll_words_holder* proximo;
    struct node_ll_words_holder* anterior;
} NODE_LL_WORDS_HOLDER;


typedef struct {
    int numeroNos;
    NODE_LL_WORDS_HOLDER* primeiroNo;
} LL_WORDS_HOLDER;




#endif //PROJETOLP_LLHOLDER_H
